UCLA pl 1.0
pchb_cloud_0_inst_O_SEND.genblk1.genblk1.bits[0].send	0	0 : N
pchb_cloud_1_inst_O_SEND.genblk1.genblk1.bits[10].send	0	0 : N
pchb_cloud_2_inst_O_SEND.genblk1.genblk1.bits[11].send	0	0 : N
I1_bitsd[0].e_terminal 0 0 : N /FIXED
I1_bitsd[10].e_terminal 0 1970 : N /FIXED
